## 1.0.1 - 2020.05.18
- fix QR to appear only in the address popup 
